vuser_end()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("boomq_auth="
		"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc19ub3RpZmljYXRlZCI6ZmFsc2UsInVzZXJfaWQiOjE5MjUsInVzZXJfbmFtZSI6ImFkbWluX2dyM0BtYWlsLmNvbSIsInNjb3BlIjpbInRydXN0IiwicmVhZCIsIndyaXRlIl0sInVzZXJfbGFuZ3VhZ2UiOiJSVSIsImV4cCI6MTc3MDA2MTczMCwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6ImQ4ZTgxYzEzLTUyZTAtNDVlNS04YjMzLWUyYTk3MTdlODFiOCIsImNsaWVudF9pZCI6ImNsaWVudCJ9.fGH52RPBYWk7B2AiqqdtOBwR9VQvgLd8F5YGlrMX67ggCxtGAHklzddACwJZhvAACIg0-9AOnfIbw6rbyPhmlGzmd_oBTM7G7hI1xdyu0n30u-RYRM5FX1nWZ26exbbPt5nB5hGcaRE1Eajgam-X"
		"dTWh0YNdVgsiF6sVD-sXqM4azlefbJh1LYTiPNdxVfBZPEC7RaANUiLd14cCiEFbUv9BMFh0lILhylTxsVRZnUo9_gR-GMZQqDToyDa3jtkN3ZK1W6-2PQnmQ4B7jo-Cev2pQzTK6j6kPgNGESFQ641K4lh3gyZMmVpqBGx4Xl7XFpSfaYAgcMzxECgLfd1Gfw; DOMAIN=dev-boomq.pflb.ru");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("sec-ch-ua", 
		"\"Chromium\";v=\"142\", \"YaBrowser\";v=\"25.12\", \"Not_A Brand\";v=\"99\", \"Yowser\";v=\"2.5\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("user", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/user", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("manifest.json", 
		"URL=https://dev-boomq.pflb.ru/manifest.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"142\", \"YaBrowser\";v=\"25.12\", \"Not_A Brand\";v=\"99\", \"Yowser\";v=\"2.5\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("identityProvider", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/identityProvider", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("22", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/team/22", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("boomq_auth="
		"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc19ub3RpZmljYXRlZCI6ZmFsc2UsInVzZXJfaWQiOjE5MjUsInVzZXJfbmFtZSI6ImFkbWluX2dyM0BtYWlsLmNvbSIsInNjb3BlIjpbInRydXN0IiwicmVhZCIsIndyaXRlIl0sInRlYW1fbWVtYmVyIjoie1wiaWRcIjoyMDA5LFwidGVhbUlkXCI6MjIsXCJ1c2VySWRcIjoxOTI1LFwiZW1haWxcIjpcImFkbWluX2dyM0BtYWlsLmNvbVwiLFwidXNlckRpc3BsYXlOYW1lXCI6XCJhZG1pbl9ncjNcIixcInBlcm1pc3Npb25MaXN0XCI6W1wiVklFV1wiLFwiQURNSU5cIixcIkVESVRcIixcIk1BTkFHRV9VU0VSU19JTl9PUkdcIixcIlJVTlwiXSxcImludml0YXRpb25TdGF0dXNcIjpcIkFDQ0VQVEVEXCIsXCJpb"
		"nZpdGVVcmxcIjpudWxsLFwiZXhwaXJlZEF0XCI6bnVsbCxcImNyZWF0ZUF0XCI6XCIyMDI2LTAxLTI4VDA3OjMxOjEwLjgyOFpcIixcInVwZGF0ZWRBdFwiOlwiMjAyNi0wMS0yOFQwNzozMjoyNy43MTJaXCJ9IiwidXNlcl9sYW5ndWFnZSI6IlJVIiwidGVhbV9pZCI6MjIsImV4cCI6MTc3MDA2MTczMCwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6IjIyZWQ1N2FhLWNmMWEtNDk5YS1hZjY4LWYyZTg0MjMyNGVkNSIsImNsaWVudF9pZCI6ImNsaWVudCJ9.PdC_0RyUt8-46HMeQ0If634p5yKnnpG5uc_J1cN3iJKj6ppSv5TbWYSZpcIUrYpwwXMZ9Gp1m3t2aK17LT_BXiReHwBGxAoayChCBxHZdZtMAsUvmskg2yBpri7k6i_d6nL2QTeyfe3R__cOzK"
		"SNaQfs55EjNF4Kk3ABh5ZgwQb0333niYkLEpBHEPuu1b8odQWiAZoIyCDHOLkhmtKIbN6vQgs4j28GVA_5EOt9aGuSHqF5ieDwFGVvWU5RFainJzoRGlSk8cp5_uWc9uwvxjjfd_lmLy6XFlIsp5rLG1lHdH0MBrBdCkmt_XnB-ZtxFd6qffyDZDXMV2XYXV4_Dg; DOMAIN=dev-boomq.pflb.ru");

	web_url("teamContext", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/teamMember/teamContext?teamId=22", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("modelSchema", 
		"URL=https://dev-boomq.pflb.ru/project-srv/modelSchema", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("testRunner", 
		"URL=https://dev-boomq.pflb.ru/test-runner-srv/testRunner?sort=id,desc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("1_END");

	lr_end_transaction("1_END",LR_AUTO);

	return 0;
}