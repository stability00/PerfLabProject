Action()
{

	lr_start_transaction("login");

	lr_end_transaction("login",LR_AUTO);

	lr_start_transaction("go_to_tests");

	lr_end_transaction("go_to_tests",LR_AUTO);

	lr_start_transaction("add_new_test");

	lr_end_transaction("add_new_test",LR_AUTO);

	lr_start_transaction("add_new_thread_gr");

	lr_end_transaction("add_new_thread_gr",LR_AUTO);

	lr_start_transaction("edit_thread_gr");

	lr_end_transaction("edit_thread_gr",LR_AUTO);

	lr_start_transaction("edit_tranzaction");

	lr_end_transaction("edit_tranzaction",LR_AUTO);

	lr_start_transaction("edit_tranzaction_1");

	lr_end_transaction("edit_tranzaction_1",LR_AUTO);

	lr_start_transaction("save_tranzaction");

	lr_end_transaction("save_tranzaction",LR_AUTO);

	lr_start_transaction("save_test");

	lr_end_transaction("save_test",LR_AUTO);

	lr_start_transaction("logout");

	lr_end_transaction("logout",LR_AUTO);

	return 0;
}